<?php
if (!class_exists('Yatra_Taxonomy_Base')) {
    abstract class Yatra_Taxonomy_Base
    {
        
    }
}