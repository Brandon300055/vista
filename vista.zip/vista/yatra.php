<?php
/**
 * Plugin Name:       Air Vista
 * Plugin URI:
 * Description:       Air Vista
 * Version:           1.0.0
 * Author:            Brandon | SUW SEO
 * Author URI:
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       vista
 * Domain Path:       /languages
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Define YATRA_PLUGIN_FILE.
if (!defined('YATRA_FILE')) {
    define('YATRA_FILE', __FILE__);
}

// Define YATRA_VERSION.
if (!defined('YATRA_VERSION')) {
    define('YATRA_VERSION', '1.0.0');
}

// Define YATRA_PLUGIN_URI.
if (!defined('YATRA_PLUGIN_URI')) {
    define('YATRA_PLUGIN_URI', plugins_url('', YATRA_FILE));
}

// Define YATRA_PLUGIN_DIR.
if (!defined('YATRA_PLUGIN_DIR')) {
    define('YATRA_PLUGIN_DIR', plugin_dir_path(YATRA_FILE));
}


// Include the main Yatra class.
if (!class_exists('Yatra')) {
    include_once dirname(__FILE__) . '/includes/class-yatra.php';
}


/**
 * Main instance of Yatra.
 *
 * Returns the main instance of Yatra to prevent the need to use globals.
 *
 * @since  1.0.0
 * @return Yatra
 */
function yatra_instance()
{
    return Yatra::instance();
}

// Global for backwards compatibility.
$GLOBALS['yatra-instance'] = yatra_instance();
