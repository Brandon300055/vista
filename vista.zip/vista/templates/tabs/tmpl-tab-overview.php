<h3 class="tab-title"><?php echo esc_html($title); ?></h3>
<div class="overview-section">
    <div class="sec-row row">
        <?php echo $overview; ?>
    </div><!-- .sec-row -->
</div>
